import pathlib

FIXTURES_PATH = (pathlib.Path(__file__).resolve().parent) / "fixtures"
